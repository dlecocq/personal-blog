#! /usr/bin/env ruby

require 'rubygems'
require 'uri'

if (ARGV.length() == 0)
  
  puts "#{$0} [weblocation [weblocation [...]] | directory]"
  exit(1)
  
end

output = "~/Desktop/bibtex.bib"

to_write = ""

for f in ARGV
  
  if (File.directory?(f))
    pwd = Dir.pwd
    Dir.chdir(f)
    for df in Dir.glob("*.webloc")
      if (File.file?(df))
        file = File.new(df,'r')

        url = URI.extract(file.read)[0]

        to_write += "@misc {#{File.basename(df, ".webloc").gsub(/^([^\.]+)\..+$/, '\1').gsub(/\s+/, "_")},
        title = \"#{File.basename(df, ".webloc")}\",
        date = \"#{file.ctime.strftime("%A %B %d, %Y %I:%M%p")}\",
        howpublished = \"\\url{#{url}}\"
        }\n\n"
        
        output = "#{f}/bibtex.bib".gsub(/\/\//, "/")

        file.close();
      end
    end
    Dir.chdir(pwd)
  else
    file = File.new(f,'r')
  
    url = URI.extract(file.read)[0]
  
    to_write += "@misc {#{File.basename(f, ".webloc").gsub(/^([^\.]+)\..+$/, '\1').gsub(/\s+/, "_")},
    title = \"#{File.basename(f, ".webloc")}\",
    date = \"#{file.ctime.strftime("%A %B %d, %Y %I:%M%p")}\",
    howpublished = \"\\url{#{url}}\"
    }\n\n"
    
    output = "#{File.split(f)[0]}/bibtex.bib".gsub(/\/\//, "/")
  
    file.close();
  end
  
end

file = File.new(output, "w+")
file.write(to_write)
file.close()
